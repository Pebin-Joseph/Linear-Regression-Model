---
title: Linear Regression
emoji: 🌍
colorFrom: red
colorTo: green
sdk: gradio
sdk_version: 5.7.1
app_file: app.py
pinned: false
short_description: this is my  first model
---

Check out the configuration reference at https://huggingface.co/docs/hub/spaces-config-reference
